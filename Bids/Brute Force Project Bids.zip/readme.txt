Team: Brute Force

Members:
Duart Breedt (u15054692)
Linda Potgieter (u14070091)
Matthew Perry (u13017030)
Mia Gerber (u15016502)
Wanrick Willemse (u29560617)

Projects in preference order:
1) Compiax - Split Bill
2) Subtrop - Harvest
3) CSIR - Electronically Timing Athletes
